function filter(arr, cond) {

    let arr = []
    for (let i = 0; i < arr.length; i++)
}